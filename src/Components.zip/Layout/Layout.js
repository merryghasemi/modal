import React from "react";

import Wrapper from './../HOC/Wrapper';

import Shopping from './../Components/Shopping/Shopping';

import './Layout.css';


class Layout extends React.Component{


    render(){

        return(


            <Wrapper>
                  <div> Navigation menu </div>

                  <Shopping/>

                  {this.props.children}

            </Wrapper>

        )
    }
}

export default Layout;